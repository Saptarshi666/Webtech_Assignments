import { Component } from '@angular/core';

@Component({
  selector: 'app-summary2',
  templateUrl: './summary2.component.html',
  styleUrl: './summary2.component.css'
})
export class Summary2Component {

}
